module.exports = function(sequelize, DataTypes) {
  const menu_master = sequelize.define('menu_master', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    moduleId: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    menuLevel: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    menuPriority: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    menuTitle: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    menuLink: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    menuStatus: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false
    },
    menuIcon: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'menu_master'
  });
  menu_master.associate = function(models) {
      menu_master.belongsTo(models.menu_modules_master, {foreignKey: 'moduleId', targetKey: 'id'});
      menu_master.hasMany(models.menu_access_map, {foreignKey: 'menuId', targetKey: 'id'});
  };
  return menu_master;
};
