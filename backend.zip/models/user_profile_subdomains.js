/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const user_profile_subdomains = sequelize.define('user_profile_subdomains', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    userSkills: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'sub_domains',
        key: 'id'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'user_profile_subdomains'
  });
  user_profile_subdomains.associate = function(models) {
    user_profile_subdomains.belongsTo(models.sub_domains,{foreignKey: 'userSkills'});
  };
  return user_profile_subdomains;
};
