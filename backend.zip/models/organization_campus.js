/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const organization_campus = sequelize.define('organization_campus', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    branchName: {
      type: DataTypes.STRING(50),
      allowNull: false
    },
    organizationId: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    address: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    city: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    pincode: {
      type: DataTypes.STRING(15),
      allowNull: false
    },
    url: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    contactPerson: {
      type: DataTypes.STRING(45),
      allowNull: false
    },
    contactPersonEmail: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    contactPersonPhone: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    contactPersonDesgination: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('active','inactive'),
      allowNull: false
    }
  }, {
    tableName: 'organization_campus'
  });
  organization_campus.associate = function(models) {
    organization_campus.hasMany(models.users, {foreignKey: 'id', targetKey: 'organizationId'});
    organization_campus.belongsTo(models.organization, {foreignKey: 'organizationId', targetKey: 'id'});
    organization_campus.hasMany(models.questions, {foreignKey: 'organizationId', targetKey: 'id'});
  };
  return organization_campus;
};
