/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  const questions = sequelize.define('questions', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    question: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    answer: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    expLevelId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'exp_level',
        key: 'id'
      }
    },
    difficulty: {
      type: DataTypes.ENUM('low','medium','heigh'),
      allowNull: false
    },
    mandatory: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    global: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    domainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'domain',
        key: 'id'
      }
    },
    subDomainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'sub_domains',
        key: 'id'
      }
    },
    keywords: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('active','inactive'),
      allowNull: false
    },
    organizationId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'organization_campus',
        key: 'id'
      }
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'questions'
  });
  questions.associate = function(models) {
    questions.belongsTo(models.organization, {foreignKey: 'organizationId', targetKey: 'id'});
    questions.belongsTo(models.domain, {foreignKey: 'domainId', targetKey: 'id'});
    questions.belongsTo(models.sub_domains, {foreignKey: 'subDomainId', targetKey: 'id'});
    questions.belongsTo(models.exp_level, {foreignKey: 'expLevelId', targetKey: 'id'});
  };
  return questions;
};
