const AsyncTest = require ('../../models').asynctest;
//const jwt = require ('jsonwebtoken');

exports.findOne = (req, res) => {
  console.log (req.body);
  AsyncTest.findOne ({
    where: {
      status: 0,
      userId: req.params.userId,
      InterviewId: req.params.InterviewId,
    },
    limit: 1,
  })
    .then (exam => {
      // Send all customers to Client
      if (exam) {
        res.send (exam);
      } else {
        res.send ({message: 'no data found!'});
      }
    })
    .catch (err => res.send ('unable to access'));
};

//update record

exports.UpdateRecord = (req, res) => {
  console.log ('data' + req.body.id);
  //res.json (req.body.id);

  AsyncTest.findOne ({
    where: {InterviewId: req.body.InterviewId, userId: req.body.userId},
    limit: 1,
  })
    .then (exam => {
      // Send all customers to Client
      if (exam) {
        AsyncTest.update (
          {
            uid: req.body.uid,
            answer: req.body.answer,
            videoURL: req.body.videoURL,
            userId: req.body.userId,
            email: req.body.email,
            status: req.body.status,
            time_taken: req.body.time_taken,
          },
          {
            where: {
              InterviewId: req.body.InterviewId,
              userId: req.body.userId,
              id: req.body.id,
            },
          }
        )
          .then (resp => res.send (resp))
          .catch (err => res.send ('unable to update'));
      } else {
        res.send ({message: 'not updated'});
      }
    })
    .catch (err => res.send ('unable to access'));
};

//find interview
exports.getVideos = (req, res) => {
  console.log (req.body);
  AsyncTest.findAll ({
    where: {
      status: 1,
      email: req.params.email,
      InterviewId: req.params.InterviewId,
    },
  })
    .then (exam => {
      // Send all customers to Client
      if (exam) {
        res.send (exam);
      } else {
        res.send ({message: 'no data found!'});
      }
    })
    .catch (err => res.send ('unable to access'));
};

//end of find interview

//find info
exports.getVideoById = (req, res) => {
  console.log (req.body);
  AsyncTest.findAll ({
    where: {
      id: req.params.id
    },
  })
    .then (exam => {
      // Send all customers to Client
      if (exam) {
        res.send (exam);
      } else {
        res.send ({message: 'no data found!'});
      }
    })
    .catch (err => res.send ('unable to access'));
};
