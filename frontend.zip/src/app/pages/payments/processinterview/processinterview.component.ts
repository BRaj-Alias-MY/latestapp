import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { ValidationService } from '../../../services/validation.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';
import {PaymentsService} from '../services/payments.service';
import Swal from 'sweetalert2/dist/sweetalert2.js'


@Component({
  selector: 'app-processinterview',
  templateUrl: './processinterview.component.html',
  styleUrls: ['./processinterview.component.css']
})
export class ProcessinterviewComponent implements OnInit {

  constructor(private fb: FormBuilder, private route: Router, private api: PaymentsService, private http: HttpClient) { }
  intid;
  usrgrp;
  btn_name: string;  

  ngOnInit() {
    this.api.get_user_groups().subscribe(res=> this.usrgrp = res.data);
    this.api.get_interviewids().subscribe(res=> this.intid = res.data);
    this.btn_name = 'Save';

  }

  processinterviewForm = this.fb.group({
    id:[],
    interviewid: [''],
    usergroups: [''],
    emails:['']
 });

 onSubmit(){
  console.log(this.processinterviewForm.value);
  this.api.saveinterview(this.processinterviewForm.value).subscribe((res) => {
     if (res.status) {
       console.log(res);
       Swal.fire('Success..', 'Interview Processed successfully.', 'success');
       this.processinterviewForm.patchValue({ interviewid: '',usergroups: '',emails: '', });


     } else {
       //this.loading.hide();
       Swal.fire('Oops...', 'Something went wrong!', 'error');
      }
   });
 
}

}
