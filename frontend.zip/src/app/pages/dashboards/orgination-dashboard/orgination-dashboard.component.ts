import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orgination-dashboard',
  templateUrl: './orgination-dashboard.component.html',
  styleUrls: ['./orgination-dashboard.component.css']
})
export class OrginationDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
