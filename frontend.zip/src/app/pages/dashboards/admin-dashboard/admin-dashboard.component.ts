import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  dasboardData: any;
  totalusers: any;

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
          ticks: {
              beginAtZero:true
          },
          scaleLabel: {
            display: true,
            labelString: 'Payments in USD'
          }
      }]
    }
  };
  public barChartLabels = [];
  public barChartType = 'bar';
  public barChartLegend = true;
  public barChartData = [
    {data: [0,0,0], label: 'Monthwise Payments'}
  ];

  public doughnutChartLabels = [];
  public doughnutChartData = [0,0,0];
  
  constructor(private api: ApiService) { }
  public doughnutChartType = 'doughnut';
  ngOnInit() {
    this.api.admindashboard().subscribe(data=>{
      this.dasboardData = data.data;
      let expertusers = this.dasboardData.usersdata.Expert ? this.dasboardData.usersdata.Expert : 0;
      let orgusers = this.dasboardData.usersdata.Organization ? this.dasboardData.usersdata.Organization : 0;
      let endusers = this.dasboardData.usersdata.User ? this.dasboardData.usersdata.User : 0;
      this.totalusers = expertusers+orgusers+endusers;
      for(let i=0;i< this.dasboardData.thismonth.length;i++){
        this.doughnutChartLabels[i] = this.dasboardData.thismonth[i].mode;
        this.doughnutChartData[i] = Number(this.dasboardData.thismonth[i].total);
      }
      for(let i=0;i< this.dasboardData.monthlydata.length;i++){
        this.barChartLabels[i] = this.dasboardData.monthlydata[i].month;
        this.barChartData[0].data[i] = Number(this.dasboardData.monthlydata[i].total);
      }
    });
  }

}
