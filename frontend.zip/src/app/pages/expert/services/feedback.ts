export class Feedback {
  interviewUserQuestionId: number;
  review: string;
  rating: string ;
}
