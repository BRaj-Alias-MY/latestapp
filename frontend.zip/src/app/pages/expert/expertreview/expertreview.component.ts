import { Component, OnInit } from '@angular/core';
import { ExpertService } from '../services/expert.service';
import { Router } from '@angular/router';
import { ReviewskillsComponent } from '../../masters/reviewskills/reviewskills.component';
import { Feedback } from '../services/feedback';

@Component({
  selector: 'app-expertreview',
  templateUrl: './expertreview.component.html',
  styleUrls: ['./expertreview.component.css']
})
export class ExpertreviewComponent implements OnInit {
  reviewId = localStorage.getItem('reviewId');
  data = [];
  videoResponse = [];
  feedback: any;
  rating: any;
  id: any;
  feed: Feedback;
  constructor(private route: Router, private api: ExpertService) {
      this.feed = new Feedback();
  }
  ngOnInit() {
    this.getQuestions();
  }
  getQuestions() {
    this.api.get_interviewQuestions(this.reviewId).subscribe(
      resp => {
        console.log(resp);
        this.data = resp;
      },
      err => console.log(err)
    );
  }
  addreview(value) {
    this.id = value;
     alert(value);
    // this.route.navigate(['/main/expertreview/', this.reviewId]);
    this.api.getInterviewById(value)
    .subscribe(resp => {this.videoResponse = resp; console.log(resp); console.log(this.videoResponse.data); }, err => console.log(err));
  }
  onSubmit(myform) {
    alert(this.id);
    this.feed.review = myform.value['reviewtext'];
    this.feed.rating = myform.value['rating_new'];
    this.feed.interviewUserQuestionId = this.id;
    console.log(this.feed);
    this.api.saveReview(this.feed).subscribe(resp => {console.log(resp);}, err => console.log(err));


  }
}
